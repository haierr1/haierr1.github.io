# Gratis fakturamal for enkeltpersonforetak

Takk for nedlastingen! Dette er den komplette fakturamalen fra **Frilans-pakken** –
helt gratis, uten vannmerke og uten registrering.

## Slik bruker du malen

1. Åpne `faktura.xlsx` i Excel, LibreOffice Calc eller Google Sheets.
2. Fyll inn de **gule feltene**: dine firmaopplysninger, kundens opplysninger,
   fakturanummer og datoer.
3. Skriv inn fakturalinjer (beskrivelse, antall, pris) og velg MVA-sats fra
   nedtrekkslisten (25 / 15 / 12 / 0) per linje.
4. Netto, MVA og totalbeløp regnes ut automatisk.
5. Lagre/eksporter som PDF og send til kunden.

Formelcellene er låst (uten passord) så du ikke sletter dem ved et uhell.

## Vil du ha hele verktøykassen?

**Frilans-pakken** inneholder tre verktøy til, laget for norske ENK:

- 💰 **Skatt & MVA-avsetning** – se nøyaktig hvor mye du bør sette av hver måned,
  fordelt på de 6 MVA-terminene. Skattesmellen kommer aldri overraskende igjen.
- 📈 **Kontantstrøm 12 måneder** – full oversikt over penger inn/ut, med diagram
  og automatisk rødmarkering av negative måneder.
- ⏱️ **Timeføring → faktura** – logg timer per kunde, få summene ferdig gruppert
  til fakturalinjer.

👉 **Få hele Frilans-pakken her: https://buy.polar.sh/polar_cl_51KJUJU0SdlxVWPgWiSGsEAAtvAm8PXgVzEkT1Ny4y6**

---
*Malen er et praktisk verktøy, ikke skatterådgivning. Kontroller alltid satser mot skatteetaten.no.*
