# Lisens – Frilans-pakken

Copyright © 2026. Alle rettigheter forbeholdt.

## Hva du får lov til

Når du har kjøpt Frilans-pakken får du en personlig, ikke-eksklusiv lisens til å:

- Bruke filene til **eget bruk og i egen virksomhet** (ditt enkeltpersonforetak
  eller annet foretak du driver).
- Redigere, tilpasse og fylle ut filene fritt til eget bruk.
- Bruke fakturaer og dokumenter du lager med malene i din egen forretning,
  overfor dine egne kunder.

## Hva du ikke har lov til

- **Videresalg, videredistribusjon eller deling** av filene (eller redigerte
  versjoner av dem), gratis eller mot betaling.
- Å gjøre filene tilgjengelige for nedlasting, i maler-samlinger, kurs eller
  pakker.
- Å publisere filene offentlig, f.eks. på nettsider, fildelingstjenester eller
  i skylagring som er delt med andre.
- Å fremstille produktet som ditt eget for videresalg.

## Ansvarsfraskrivelse

Frilans-pakken leveres «som den er», uten noen form for garanti. Dette er
**verktøy, ikke skatte-, regnskaps- eller juridisk rådgivning**. Alle satser er
redigerbare og må kontrolleres mot **skatteetaten.no** og din egen situasjon.
Selger er ikke ansvarlig for feil, tap eller beslutninger tatt på grunnlag av
bruk av filene. Du er selv ansvarlig for at dine skatte-, MVA- og
regnskapsforpliktelser oppfylles korrekt.

Trenger flere lisenser til et team eller en organisasjon? Ta kontakt via
Gumroad-kvitteringen.
